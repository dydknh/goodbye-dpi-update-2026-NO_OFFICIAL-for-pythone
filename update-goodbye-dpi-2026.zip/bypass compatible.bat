@echo off
call "%~dp0all bypass.bat" --profile compatible
exit /b %errorlevel%
