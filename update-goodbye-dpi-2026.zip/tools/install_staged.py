"""Back up original distribution, then copy only official binaries and lists."""
from pathlib import Path
import hashlib
import json
import shutil
from datetime import datetime

ROOT = Path(__file__).resolve().parents[1]
stage = ROOT / '.update/official-0.2.3rc3/goodbyedpi-0.2.3rc3-2'
backup = ROOT / 'backups' / datetime.now().strftime('%Y%m%d-%H%M%S')
backup.mkdir(parents=True, exist_ok=False)
for path in list(ROOT.glob('*.cmd')) + list(ROOT.glob('*.txt')) + [ROOT/'x86', ROOT/'x86_64', ROOT/'licenses']:
    dest = backup / path.name
    if path.is_dir():
        shutil.copytree(path, dest)
    else:
        shutil.copy2(path, dest)
manifest = {}
for folder in ('x86', 'x86_64', 'licenses'):
    for path in (stage / folder).rglob('*'):
        if path.is_file():
            rel = path.relative_to(stage)
            dest = ROOT / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, dest)
            manifest[str(rel)] = hashlib.sha256(dest.read_bytes()).hexdigest()
for name in ('russia-blacklist.txt', 'russia-youtube.txt'):
    shutil.copy2(stage/name, ROOT/name)
(ROOT/'tools/official-manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
print('Backup:', backup)
print('Official binaries, licenses and release lists copied; services and network untouched.')
