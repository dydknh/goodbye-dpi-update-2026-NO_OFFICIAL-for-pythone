"""GoodbyeDPI launcher. Uses Python standard library; no PowerShell required."""
import argparse
import ctypes
import ipaddress
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import urllib.parse

ROOT = Path(__file__).resolve().parents[1]

def admin():
    if not ctypes.windll.shell32.IsUserAnAdmin():
        raise RuntimeError('Run this CMD file as administrator (right click).')

def launch(profile):
    arch = os.environ.get('PROCESSOR_ARCHITEW6432') or os.environ.get('PROCESSOR_ARCHITECTURE')
    if arch not in ('AMD64', 'x86'):
        raise ValueError('Unsupported architecture: ' + str(arch))
    folder = ROOT / ('x86_64' if arch == 'AMD64' else 'x86')
    for name in ('goodbyedpi.exe', 'WinDivert.dll', 'WinDivert64.sys' if arch == 'AMD64' else 'WinDivert32.sys'):
        if not (folder/name).is_file():
            raise ValueError('Missing file: ' + str(folder/name))
    profiles = json.loads((ROOT/'config/profiles.json').read_text(encoding='utf-8-sig'))
    if profile not in profiles:
        raise ValueError('Unknown profile: ' + profile)
    config = profiles[profile]
    args = list(config['args'])
    for name in config['lists']:
        path = ROOT/name
        if not path.is_file() or not path.stat().st_size:
            raise ValueError('Empty list or missing list: ' + name)
        args.extend(['--blacklist', str(path)])
    if any(not isinstance(token, str) or any(c in token for c in '\r\n"') for token in args):
        raise ValueError('Invalid profile token')
    return [str(folder/'goodbyedpi.exe'), *args]

def service_exists():
    result = subprocess.run(['sc.exe', 'query', 'GoodbyeDPI'], capture_output=True)
    if result.returncode not in (0, 1060):
        raise RuntimeError('Cannot query service: ' + str(result.returncode))
    return result.returncode == 0

def running():
    result = subprocess.run(['tasklist.exe', '/FI', 'IMAGENAME eq goodbyedpi.exe', '/FO', 'CSV', '/NH'], capture_output=True, text=True, errors='replace', check=True)
    return '"goodbyedpi.exe"' in result.stdout.lower()

def update(source):
    if urllib.parse.urlparse(source).scheme != 'https':
        raise ValueError('List source must use HTTPS')
    target = ROOT/'russia-blacklist.txt'
    request = urllib.request.Request(source, headers={'User-Agent': 'GoodbyeDPI-local-maintenance'})
    with urllib.request.urlopen(request, timeout=45) as response:
        if urllib.parse.urlparse(response.url).scheme != 'https':
            raise ValueError('Insecure redirect')
        data = response.read(30*1024*1024+1)
    if not 100 <= len(data) <= 30*1024*1024:
        raise ValueError('Unexpected list size')
    domains = set()
    pattern = re.compile(r'(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?')
    for line in data.decode('utf-8-sig').splitlines():
        domain = line.strip().rstrip('.').lower()
        if not domain or domain.startswith('#'):
            continue
        if len(domain) > 253 or not pattern.fullmatch(domain):
            raise ValueError('Response is not a domain list; original preserved')
        try:
            ipaddress.ip_address(domain)
        except ValueError:
            pass
        else:
            raise ValueError('IP address instead of domain; original preserved')
        domains.add(domain)
    if len(domains) < 10:
        raise ValueError('Too few domains; original preserved')
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=ROOT, prefix='.blacklist-', suffix='.tmp', delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(('\n'.join(sorted(domains))+'\n').encode('ascii'))
        if target.exists():
            shutil.copy2(target, str(target)+'.bak')
        os.replace(temporary, target)
        print('Updated:', len(domains), 'domains. Restart GoodbyeDPI to reload.')
    finally:
        if temporary and temporary.exists():
            temporary.unlink()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('-Action', choices=['Run','Preview','Check','Update','Install','Remove'], default='Check')
    parser.add_argument('-Profile', default='standard')
    parser.add_argument('-ListSource', default='https://p.thenewone.lol/domains-export.txt')
    options = parser.parse_args()
    if options.Action == 'Update':
        update(options.ListSource)
        return
    if options.Action == 'Remove':
        admin()
        if not service_exists():
            print('GoodbyeDPI service is not installed.')
            return
        # sc stop may report already stopped. Never delete shared driver services.
        result = subprocess.run(['sc.exe', 'stop', 'GoodbyeDPI'])
        if result.returncode not in (0, 1062):
            raise RuntimeError('Service stop failed: ' + str(result.returncode))
        subprocess.run(['sc.exe','delete','GoodbyeDPI'], check=True)
        print('GoodbyeDPI removed. Shared WinDivert services NOT deleted.')
        return
    command = launch(options.Profile)
    if options.Action == 'Preview':
        print(subprocess.list2cmdline(command))
        return
    if options.Action == 'Check':
        admin()
        subprocess.run([command[0], '--help'], check=True)
        print('Files and profile OK. Help only; packet filtering was not started.')
        return
    admin()
    if running():
        raise RuntimeError('GoodbyeDPI already running. Close it first.')
    if service_exists():
        raise RuntimeError('GoodbyeDPI service exists. Stop/remove it explicitly before a manual run or reinstall.')
    if options.Action == 'Install':
        subprocess.run(['sc.exe','create','GoodbyeDPI','binPath=',subprocess.list2cmdline(command),'start=','auto'], check=True)
        subprocess.run(['sc.exe','description','GoodbyeDPI','GoodbyeDPI DPI circumvention'], check=True)
        subprocess.run(['sc.exe','start','GoodbyeDPI'], check=True)
        print('Service installed and start requested.')
        return
    print('Profile:', options.Profile, '- stop with Ctrl+C or close this window.', flush=True)
    subprocess.run(command, cwd=Path(command[0]).parent, check=True)

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(130)
    except Exception as error:
        print('ERROR:', error, file=sys.stderr)
        sys.exit(1)
