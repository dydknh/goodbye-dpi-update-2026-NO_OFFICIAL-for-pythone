"""Interactive Windows launcher. Elevates only an explicitly selected action."""
import argparse
import ctypes
from pathlib import Path
import subprocess
import sys

import manage

ROOT = Path(__file__).resolve().parents[1]
PROFILES = (
    ('strong', 'Усиленный — дополнительные поддельные пакеты'),
    ('strong-dns', 'Усиленный + DNS — если провайдер подменяет DNS'),
    ('sni', 'Разделение TLS по SNI — альтернативный способ'),
    ('standard', 'Основной официальный -9'),
    ('standard-dns', 'Основной + DNS'),
    ('youtube', 'YouTube'),
    ('compatible', 'Совместимый -6 -q'),
    ('legacy', 'Старый совместимый -1 -q'),
    ('russia', 'Только домены из списков'),
    ('russia-dns', 'Только списки + DNS'),
)


def command(action, profile):
    # Validate before asking for elevation. Never accept an arbitrary command.
    if action not in ('Run', 'Check', 'Update', 'Install', 'Remove'):
        raise ValueError('Unknown action')
    manage.launch(profile)
    return [sys.executable, str(ROOT / 'tools/manage.py'),
            '-Action', action, '-Profile', profile]


def execute(action, profile, elevated=False):
    cmd = command(action, profile)
    if action != 'Update' and not ctypes.windll.shell32.IsUserAnAdmin():
        if elevated:
            raise RuntimeError('Windows не предоставила права администратора.')
        params = subprocess.list2cmdline([
            str(Path(__file__).resolve()), '--action', action,
            '--profile', profile, '--elevated'])
        result = ctypes.windll.shell32.ShellExecuteW(
            None, 'runas', sys.executable, params, str(ROOT), 1)
        if result <= 32:
            raise RuntimeError('Запуск отменён или Windows отказала в повышении прав.')
        print('Запрос запуска передан Windows. Подтверди запрос прав администратора.')
        return 0
    return subprocess.run(cmd, cwd=ROOT).returncode


def menu():
    while True:
        print('\n=== GoodbyeDPI — все режимы ===')
        for index, (_, label) in enumerate(PROFILES, 1):
            print(f'{index}. {label}')
        print('U. Обновить список доменов\nD. Диагностика без фильтрации')
        print('I. Установить основной режим как службу автозапуска')
        print('R. Удалить службу GoodbyeDPI\n0. Выход')
        print('Перед сменой режима закрой предыдущее окно GoodbyeDPI.')
        choice = input('Выбери действие: ').strip().lower()
        if choice == '0':
            return 0
        if choice.isdecimal() and 1 <= int(choice) <= len(PROFILES):
            profile = PROFILES[int(choice) - 1][0]
            subprocess.Popen([sys.executable, str(Path(__file__).resolve()),
                              '--profile', profile], cwd=ROOT,
                             creationflags=subprocess.CREATE_NEW_CONSOLE)
            continue
        actions = {'u': 'Update', 'd': 'Check', 'i': 'Install', 'r': 'Remove'}
        if choice not in actions:
            print('Нет такого пункта.')
            continue
        action = actions[choice]
        if action in ('Install', 'Remove'):
            if input('Это изменит службу Windows. Введи ДА для подтверждения: ').strip() != 'ДА':
                continue
        subprocess.Popen([sys.executable, str(Path(__file__).resolve()),
                          '--action', action, '--profile', 'standard'], cwd=ROOT,
                         creationflags=subprocess.CREATE_NEW_CONSOLE)


def main():
    parser = argparse.ArgumentParser(description='GoodbyeDPI: запуск или общее меню')
    parser.add_argument('--menu', action='store_true')
    parser.add_argument('--profile', choices=[p[0] for p in PROFILES], default='strong')
    parser.add_argument('--action', choices=['Run', 'Check', 'Update', 'Install', 'Remove'], default='Run')
    parser.add_argument('--preview', action='store_true')
    parser.add_argument('--elevated', action='store_true')
    options = parser.parse_args()
    if options.preview:
        print(subprocess.list2cmdline(command(options.action, options.profile)))
        return 0
    if options.menu:
        return menu()
    result = execute(options.action, options.profile, options.elevated)
    if result or options.action != 'Run':
        input('Нажми Enter, чтобы закрыть окно...')
    return result


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (KeyboardInterrupt, EOFError):
        sys.exit(130)
    except Exception as error:
        print('Ошибка:', error, file=sys.stderr)
        try:
            input('Нажми Enter, чтобы закрыть окно...')
        except (KeyboardInterrupt, EOFError):
            pass
        sys.exit(1)
