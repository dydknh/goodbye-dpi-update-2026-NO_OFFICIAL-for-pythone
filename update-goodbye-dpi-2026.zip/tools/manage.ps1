param(
    [ValidateSet('Run','Preview','Check','Update','Install','Remove')]
    [string]$Action = 'Check',
    [string]$Profile = 'standard',
    [string]$ListSource = 'https://p.thenewone.lol/domains-export.txt'
)
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot

function Assert-Admin {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'Run this CMD file as administrator (right click).'
    }
}
function Get-Launch {
    $arch = $env:PROCESSOR_ARCHITECTURE
    if ($env:PROCESSOR_ARCHITEW6432) { $arch = $env:PROCESSOR_ARCHITEW6432 }
    switch ($arch) {
        'AMD64' { $folder = 'x86_64' }
        'x86' { $folder = 'x86' }
        default { throw "Unsupported architecture: $arch. ARM64 driver is not included." }
    }
    $exe = Join-Path $Root "$folder\goodbyedpi.exe"
    foreach ($name in @('goodbyedpi.exe','WinDivert.dll')) {
        if (-not (Test-Path -LiteralPath (Join-Path $Root "$folder\$name") -PathType Leaf)) {
            throw "Missing file: $folder\$name"
        }
    }
    $driver = 'WinDivert64.sys'
    if ($arch -eq 'x86') { $driver = 'WinDivert32.sys' }
    if (-not (Test-Path -LiteralPath (Join-Path $Root "$folder\$driver") -PathType Leaf)) {
        throw "Missing driver: $driver"
    }
    $profiles = Get-Content -LiteralPath (Join-Path $Root 'config\profiles.json') -Raw | ConvertFrom-Json
    if ($Profile -notin $profiles.PSObject.Properties.Name) { throw "Unknown profile: $Profile" }
    $config = $profiles.$Profile
    $arguments = @($config.args)
    foreach ($list in $config.lists) {
        $path = Join-Path $Root $list
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "Missing list: $list" }
        if ((Get-Item -LiteralPath $path).Length -eq 0) { throw "Empty list: $list" }
        $arguments += @('--blacklist', $path)
    }
    # Only data tokens are allowed; no shell expressions or embedded quotes.
    foreach ($token in $arguments) {
        if ($token -match '["\r\n]') { throw 'Invalid quote or newline in profile.' }
    }
    [pscustomobject]@{ Exe = $exe; Arguments = $arguments }
}
function Invoke-SC([string[]]$Tokens) {
    & "$env:SystemRoot\System32\sc.exe" @Tokens | Out-Host
    if ($LASTEXITCODE -ne 0) { throw "Service command failed: $($Tokens -join ' ') (code $LASTEXITCODE)" }
}
function Update-List {
    $uri = [Uri]$ListSource
    if ($uri.Scheme -ne 'https') { throw 'List source must use HTTPS.' }
    $target = Join-Path $Root 'russia-blacklist.txt'
    $temp = Join-Path $Root ('.blacklist-' + [Guid]::NewGuid().ToString('N') + '.tmp')
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -Uri $uri -OutFile $temp -UseBasicParsing -TimeoutSec 45 -MaximumRedirection 3
        $size = (Get-Item -LiteralPath $temp).Length
        if ($size -lt 100 -or $size -gt 30MB) { throw "Unexpected list size: $size" }
        $domains = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
        foreach ($line in [IO.File]::ReadLines($temp)) {
            $domain = $line.Trim().TrimEnd('.').ToLowerInvariant()
            if (-not $domain -or $domain.StartsWith('#')) { continue }
            if ($domain.Length -gt 253 -or $domain -notmatch '^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$') {
                throw 'Response is not a domain list; original file preserved.'
            }
            [void]$domains.Add($domain)
        }
        if ($domains.Count -lt 10) { throw 'Too few domains; original file preserved.' }
        [IO.File]::WriteAllLines($temp, [string[]]($domains | Sort-Object), [Text.Encoding]::ASCII)
        if (Test-Path -LiteralPath $target) {
            [IO.File]::Replace($temp, $target, "$target.bak")
        } else { [IO.File]::Move($temp, $target) }
        Write-Host "Updated: $($domains.Count) domains. Restart GoodbyeDPI to reload."
    } finally {
        if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp }
    }
}
try {
    if ($Action -eq 'Update') { Update-List; exit 0 }
    if ($Action -eq 'Remove') {
        Assert-Admin
        $service = Get-Service -Name GoodbyeDPI -ErrorAction SilentlyContinue
        if (-not $service) { Write-Host 'GoodbyeDPI service is not installed.'; exit 0 }
        if ($service.Status -ne 'Stopped') {
            Stop-Service -Name GoodbyeDPI
            $service.WaitForStatus('Stopped', [TimeSpan]::FromSeconds(20))
        }
        Invoke-SC @('delete','GoodbyeDPI')
        Write-Host 'GoodbyeDPI service removed. Shared WinDivert services were NOT deleted.'
        exit 0
    }
    $launch = Get-Launch
    $quoted = @($launch.Arguments | ForEach-Object { '"' + $_ + '"' }) -join ' '
    if ($Action -eq 'Preview') { Write-Output ('"' + $launch.Exe + '" ' + $quoted); exit 0 }
    if ($Action -eq 'Check') {
        Write-Host "Executable: $($launch.Exe)"
        & $launch.Exe --help
        if ($LASTEXITCODE -ne 0) { throw "Help exited with code $LASTEXITCODE" }
        Write-Host 'Files and profile OK. Help only; packet filtering was not started.'
        Get-Service -Name GoodbyeDPI -ErrorAction SilentlyContinue | Format-Table Name,Status
        exit 0
    }
    Assert-Admin
    $service = Get-Service -Name GoodbyeDPI -ErrorAction SilentlyContinue
    if ($Action -eq 'Install') {
        if ($service) { throw 'GoodbyeDPI service exists. Remove it explicitly first; configuration was not overwritten.' }
        if (Get-Process -Name goodbyedpi -ErrorAction SilentlyContinue) { throw 'Close the running GoodbyeDPI first.' }
        $binary = '"' + $launch.Exe + '" ' + $quoted
        Invoke-SC @('create','GoodbyeDPI','binPath=', $binary, 'start=', 'auto')
        Invoke-SC @('description','GoodbyeDPI','GoodbyeDPI DPI circumvention')
        Invoke-SC @('start','GoodbyeDPI')
        Write-Host 'Service installed. If startup failed, inspect it; do not repeatedly install.'
        exit 0
    }
    if ($service -and $service.Status -ne 'Stopped') { throw 'Stop the GoodbyeDPI service before a manual run.' }
    if (Get-Process -Name goodbyedpi -ErrorAction SilentlyContinue) { throw 'GoodbyeDPI is already running. Close its window first.' }
    Write-Host "Profile: $Profile. Stop with Ctrl+C or close this window."
    # Working directory and explicit quoting also support spaces in the project path.
    $process = Start-Process -FilePath $launch.Exe -ArgumentList $quoted -WorkingDirectory (Split-Path $launch.Exe) -NoNewWindow -Wait -PassThru
    if ($process.ExitCode -ne 0) { throw "GoodbyeDPI exited with code $($process.ExitCode)" }
    exit 0
} catch {
    [Console]::Error.WriteLine('ERROR: ' + $_.Exception.Message)
    exit 1
}
