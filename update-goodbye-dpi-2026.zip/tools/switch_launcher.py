"""Migrate this local bundle's CMD wrappers to the available Python runtime."""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
for path in ROOT.glob('*.cmd'):
    text = path.read_text(encoding='utf-8-sig')
    text = text.replace('powershell.exe -NoLogo -NoProfile -File "%~dp0tools\\manage.ps1"', 'python "%~dp0tools\\manage.py"')
    path.write_bytes(text.replace('\r\n', '\n').replace('\n', '\r\n').encode('utf-8'))
print('CMD launchers now use installed Python; Windows execution policy unchanged.')
