"""Launcher regressions: real cmd.exe previews; no filtering or UAC requests."""
import contextlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest
from unittest.mock import patch

import launcher

ROOT = Path(__file__).resolve().parents[1]
FILES = {
    'bypass strong.bat': 'strong',
    'bypass strong dns.bat': 'strong-dns',
    'bypass sni.bat': 'sni',
    'bypass standard.bat': 'standard',
    'bypass standard dns.bat': 'standard-dns',
    'bypass youtube.bat': 'youtube',
    'bypass compatible.bat': 'compatible',
    'bypass legacy.bat': 'legacy',
    'bypass russia.bat': 'russia',
    'bypass russia dns.bat': 'russia-dns',
}


def cmd(root, name, args='', input=None):
    return subprocess.run(f'cmd.exe /d /c call "{root / name}" {args}',
                          input=input if input is not None else '\n\n', capture_output=True, text=True,
                          encoding='utf-8', errors='replace', timeout=30)


class LauncherTests(unittest.TestCase):
    def test_all_default_is_strong(self):
        result = cmd(ROOT, 'all bypass.bat', '--preview')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn('-Action Run -Profile strong', result.stdout)

    def test_every_bat_and_paths_with_spaces(self):
        with tempfile.TemporaryDirectory(prefix='GoodbyeDPI launcher spaces ') as directory:
            root = Path(directory)
            for folder in ('tools', 'config', 'x86', 'x86_64'):
                shutil.copytree(ROOT / folder, root / folder)
            for name in ('russia-blacklist.txt', 'russia-youtube.txt', 'all bypass.bat', 'START.cmd', *FILES):
                shutil.copy2(ROOT / name, root / name)
            # Append preview only in the disposable copy; real wrapper routing is exercised.
            for name, profile in FILES.items():
                path = root / name
                path.write_text(path.read_text().replace('--profile ', '--preview --profile '))
                result = cmd(root, name)
                self.assertEqual(result.returncode, 0, (name, result.stdout, result.stderr))
                self.assertIn('-Action Run -Profile ' + profile, result.stdout)
                self.assertIn('"' + str(root / 'tools/manage.py') + '"', result.stdout)
            result = cmd(root, 'START.cmd', input='0\n')
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn('10.', result.stdout)
            self.assertIn('GoodbyeDPI', result.stdout)

    def test_menu_invalid_then_exit(self):
        with patch('builtins.input', side_effect=['invalid', '0']), contextlib.redirect_stdout(io.StringIO()) as out:
            self.assertEqual(launcher.menu(), 0)
        self.assertIn('Нет такого пункта', out.getvalue())

    def test_cancel_service_change(self):
        with patch('builtins.input', side_effect=['i', 'нет', 'r', 'нет', '0']), patch('launcher.subprocess.Popen') as start, contextlib.redirect_stdout(io.StringIO()):
            launcher.menu()
        start.assert_not_called()

    def test_reject_unknown_action(self):
        with self.assertRaises(ValueError):
            launcher.command('anything', 'strong')

    def test_uac_cancel_no_child(self):
        # Unit check only: the real Windows UAC dialog is deliberately not opened.
        with patch('launcher.ctypes.windll.shell32.IsUserAnAdmin', return_value=0), patch('launcher.ctypes.windll.shell32.ShellExecuteW', return_value=5), patch('launcher.subprocess.run') as child:
            with self.assertRaises(RuntimeError):
                launcher.execute('Run', 'strong')
            child.assert_not_called()

    def test_uac_success_and_no_recursion(self):
        with patch('launcher.ctypes.windll.shell32.IsUserAnAdmin', return_value=0), patch('launcher.ctypes.windll.shell32.ShellExecuteW', return_value=42) as elevate, contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(launcher.execute('Run', 'strong'), 0)
            self.assertIn('--elevated', elevate.call_args.args[3])
            with self.assertRaises(RuntimeError):
                launcher.execute('Run', 'strong', elevated=True)
            self.assertEqual(elevate.call_count, 1)

    def test_menu_covers_every_profile(self):
        profiles = json.loads((ROOT / 'config/profiles.json').read_text())
        self.assertEqual(set(profiles), {p[0] for p in launcher.PROFILES})
        self.assertEqual(set(profiles), set(FILES.values()))


if __name__ == '__main__':
    unittest.main(verbosity=2)
