"""Download and stage the pinned official release; never execute its contents."""
import hashlib
import io
from pathlib import Path
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]
URL = 'https://github.com/ValdikSS/GoodbyeDPI/releases/download/0.2.3rc3/goodbyedpi-0.2.3rc3-2.zip'

def main():
    request = urllib.request.Request(URL, headers={'User-Agent': 'GoodbyeDPI-local-maintenance'})
    with urllib.request.urlopen(request, timeout=60) as response:
        data = response.read(8 * 1024 * 1024 + 1)
    if len(data) > 8 * 1024 * 1024:
        raise ValueError('Archive exceeds size limit')
    stage = ROOT / '.update' / 'official-0.2.3rc3'
    stage.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        bad = archive.testzip()
        if bad:
            raise ValueError('Invalid ZIP CRC: ' + bad)
        for entry in archive.infolist():
            path = Path(entry.filename)
            if path.is_absolute() or '..' in path.parts or ':' in entry.filename:
                raise ValueError('Unsafe archive path')
        archive.extractall(stage)
    print('Official archive SHA256:', hashlib.sha256(data).hexdigest())
    print('Staged at:', stage)
    for path in sorted(stage.rglob('*.cmd')):
        print('\n---', path.relative_to(stage), '---\n', path.read_text(errors='replace'))

if __name__ == '__main__':
    main()
