"""Non-invasive Windows checks: no packet filtering or service changes."""
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
import shutil

ROOT = Path(__file__).resolve().parents[1]
import sys

def invoke(root, *args):
    result = subprocess.run([sys.executable, str(root/'tools/manage.py'), *args], capture_output=True, text=True, errors='replace', timeout=65)
    return result

def main():
    manifest = json.loads((ROOT/'tools/official-manifest.json').read_text())
    for name, expected in manifest.items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest() == expected, name
    print('PASS: official file hashes match staged release')
    profiles = json.loads((ROOT/'config/profiles.json').read_text())
    for profile, config in profiles.items():
        result = invoke(ROOT, '-Action', 'Preview', '-Profile', profile)
        assert result.returncode == 0, (profile, result.stdout, result.stderr)
        for token in config['args']:
            assert token in result.stdout, (profile, token, result.stdout)
        for name in config['lists']:
            assert str(ROOT/name) in result.stdout
        print('PASS: preview', profile)
    bad = invoke(ROOT, '-Action', 'Preview', '-Profile', 'not-a-profile')
    assert bad.returncode != 0 and 'Unknown profile' in bad.stderr, (bad.stdout, bad.stderr)
    print('PASS: unknown profile rejected')
    with tempfile.TemporaryDirectory(prefix='GoodbyeDPI checks with spaces ') as temporary:
        root = Path(temporary)
        shutil.copytree(ROOT/'tools', root/'tools')
        shutil.copytree(ROOT/'config', root/'config')
        for folder in ('x86', 'x86_64'):
            shutil.copytree(ROOT/folder, root/folder)
        for name in ('russia-blacklist.txt', 'russia-youtube.txt'):
            shutil.copy2(ROOT/name, root/name)
        result = invoke(root, '-Action', 'Preview', '-Profile', 'russia')
        assert result.returncode == 0 and '"'+str(root/'russia-blacklist.txt')+'"' in result.stdout, (result.stdout, result.stderr)
        print('PASS: path containing spaces quoted')
        (root/'russia-blacklist.txt').write_text('')
        result = invoke(root, '-Action', 'Preview', '-Profile', 'russia')
        assert result.returncode != 0 and 'Empty list' in result.stderr
        print('PASS: empty list rejected')
        original = b'example.com\n'
        (root/'russia-blacklist.txt').write_bytes(original)
        result = invoke(root, '-Action', 'Update', '-ListSource', 'http://example.com/list.txt')
        assert result.returncode != 0 and 'HTTPS' in result.stderr
        assert (root/'russia-blacklist.txt').read_bytes() == original
        print('PASS: insecure update rejected, original preserved')
        result = invoke(root, '-Action', 'Update')
        if result.returncode == 0:
            assert (root/'russia-blacklist.txt.bak').read_bytes() == original
            print('PASS: live HTTPS update in isolated copy; backup preserved')
        else:
            assert (root/'russia-blacklist.txt').read_bytes() == original
            print('UNVERIFIED: live list source unavailable or invalid:', result.stderr.strip())
            print('PASS: failed live update preserved original')
    result = invoke(ROOT, '-Action', 'Check')
    print('DIAGNOSTICS STDOUT:', result.stdout)
    print('DIAGNOSTICS STDERR:', result.stderr)
    if result.returncode == 0:
        print('PASS: help-only runtime diagnostics; no network filtering started')
    elif 'Run this CMD file as administrator' in result.stderr:
        print('PASS: diagnostics clearly require administrator privileges')
        print('UNVERIFIED: executable help and driver loading require elevation; filtering NOT started')
    else:
        raise AssertionError('Help-only runtime check failed unexpectedly')
    print('PASS: all non-invasive checks completed')

if __name__ == '__main__':
    main()
