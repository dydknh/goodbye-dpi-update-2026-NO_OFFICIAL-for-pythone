@echo off
call "%~dp0all bypass.bat" --profile legacy
exit /b %errorlevel%
