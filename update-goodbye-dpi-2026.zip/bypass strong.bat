@echo off
call "%~dp0all bypass.bat" --profile strong
exit /b %errorlevel%
