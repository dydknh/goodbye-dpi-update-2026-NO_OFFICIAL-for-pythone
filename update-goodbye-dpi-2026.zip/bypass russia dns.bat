@echo off
call "%~dp0all bypass.bat" --profile russia-dns
exit /b %errorlevel%
