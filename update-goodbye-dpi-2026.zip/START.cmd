@echo off
setlocal
call "%~dp0all bypass.bat" --menu
exit /b %errorlevel%
