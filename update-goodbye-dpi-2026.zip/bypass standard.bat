@echo off
call "%~dp0all bypass.bat" --profile standard
exit /b %errorlevel%
