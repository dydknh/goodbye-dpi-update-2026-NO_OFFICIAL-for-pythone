@echo off
setlocal
python "%~dp0tools\manage.py" -Action Install -Profile russia
set "rc=%errorlevel%"
pause
exit /b %rc%
