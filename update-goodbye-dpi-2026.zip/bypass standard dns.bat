@echo off
call "%~dp0all bypass.bat" --profile standard-dns
exit /b %errorlevel%
