@echo off
call "%~dp0all bypass.bat" --profile sni
exit /b %errorlevel%
