@echo off
call "%~dp0all bypass.bat" --profile russia
exit /b %errorlevel%
