@echo off
setlocal
python "%~dp0tools\manage.py" -Action Remove
set "rc=%errorlevel%"
pause
exit /b %rc%
