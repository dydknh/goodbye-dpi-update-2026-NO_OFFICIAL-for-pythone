@echo off
setlocal
chcp 65001 >nul
title GoodbyeDPI - all bypass
where python >nul 2>nul
if errorlevel 1 (
 echo Python не найден. Установи Python и добавь его в PATH.
 pause
 exit /b 1
)
python "%~dp0tools\launcher.py" %*
set "rc=%errorlevel%"
if not "%rc%"=="0" pause
exit /b %rc%
