@echo off
setlocal
python "%~dp0tools\manage.py" -Action Check
set "rc=%errorlevel%"
pause
exit /b %rc%
