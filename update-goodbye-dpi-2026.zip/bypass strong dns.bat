@echo off
call "%~dp0all bypass.bat" --profile strong-dns
exit /b %errorlevel%
