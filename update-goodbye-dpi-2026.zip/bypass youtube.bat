@echo off
call "%~dp0all bypass.bat" --profile youtube
exit /b %errorlevel%
