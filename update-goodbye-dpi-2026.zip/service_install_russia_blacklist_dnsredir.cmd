@echo off
setlocal
python "%~dp0tools\manage.py" -Action Install -Profile russia-dns
set "rc=%errorlevel%"
pause
exit /b %rc%
